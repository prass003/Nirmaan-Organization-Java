package BookManagementSYstem2;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
public class UI {
	public static void main(String[] args) {
		List<BookInfo> ll = new LinkedList<BookInfo>();
		Scanner sc = new Scanner(System.in);
		BookInfo std = new BookInfo();
		BookService service = new BookService();
		while (true) {
			System.out.println("Enter your Choice");
			System.out.println("1 for post Books");
			System.out.println("2 for get All Books");
			System.out.println("3 for get Book By Id ");
			System.out.println(("4 for put Books")); 
			System.out.println("5 for delete Book By Id");
			int key = sc.nextInt();
			switch(key) {
			case 1:
				ll.add(service.addBooks());
			break;
			case 2:
				service.getBooks(ll);
			break;
			case 3:
				BookInfo existBook = service.getBookById(ll);
				if (existBook != null) {
					System.out.println(existBook);
				} else {
					System.out.println("Book Not Found");
				}
			break;
			case 4:
				ll = service.putBooks(ll);
			break;
			case 5:
				ll = service.deleteBooks(ll);
			break;
			default :
				System.out.println("Enter the Correct Option");
			}
		}

	}

}


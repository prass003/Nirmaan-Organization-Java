package BookManagementSYstem2;

public class BookInfo {
	private int Bookid;
	private String Bookname;
	private String Bookauthor;
	private double price;
	public int getBookid() {
		return Bookid;
	}
	public void setBookid(int bookid) {
		Bookid = bookid;
	}
	public String getBookname() {
		return Bookname;
	}
	public void setBookname(String bookname) {
		Bookname = bookname;
	}
	public String getBookauthor() {
		return Bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		Bookauthor = bookauthor;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public BookInfo(int bookid, String bookname, String bookauthor, double price) {
		super();
		Bookid = bookid;
		Bookname = bookname;
		Bookauthor = bookauthor;
		this.price = price;
	}
	public BookInfo() {
		super();
	}
	@Override
	public String toString() {
		return "BookInfo [Bookid=" + Bookid + ", Bookname=" + Bookname + ", Bookauthor=" + Bookauthor + ", price="
				+ price + "]";
	}

	

}

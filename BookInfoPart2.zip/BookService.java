package BookManagementSYstem2;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import day8.Student;

public class BookService {
	Scanner sc = new Scanner(System.in);
	public BookInfo addBooks() {
		BookInfo bok = new BookInfo();
		System.out.println("Enter the Book Id : ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Book Name :");
		String Name = sc.nextLine();
		System.out.println("Enter the Book Author : ");
		String author = sc.nextLine();
		System.out.println("Enter the price ");
		double price = sc.nextDouble();
		bok = new BookInfo(id, Name, author, price);
		return bok;
	}
	public void getBooks(List<BookInfo> B) {
		System.out.println(B);
	}
	public BookInfo getBookById(List<BookInfo> b) {

		System.out.println("Enter the Book Id for show : ");
		int id = sc.nextInt();

		for (BookInfo boo : b) {
			if (id == boo.getBookid()) {
				return boo;
			}
		}
		return null;
	}
	public List<BookInfo> putBooks(List<BookInfo> b) {
		System.out.println("Enter the Book Id for Update : ");
		int id = sc.nextInt();
		sc.nextLine();
		for(BookInfo boo2 : b) {
			if(boo2.getBookid()==id) {
				System.out.println("Enter the Book Name :");
				String Name = sc.nextLine();
				System.out.println("Enter the Book Author : ");
				String author = sc.nextLine();
				System.out.println("Enter the Price  ");
				long price = sc.nextLong();
				boo2.setBookname(Name);
				boo2.setBookauthor(author);
				boo2.setPrice(price);
			}
		}
		return b;
	}
	public List<BookInfo> deleteBooks(List<BookInfo> b){
		System.out.println("Enter the Book Id for delete : ");
		int id = sc.nextInt();
		for (BookInfo Boo3 : b) {
			if (id == Boo3.getBookid()) {
				b.remove(Boo3);
				return b;
			}
		}
		return b;
	}
 
}


package day16;

public class Hierarycal {

	public static void main(String[] args) {
		Bike b = new Bike();
		b.StartEngine();
		b.Start();

	}

}

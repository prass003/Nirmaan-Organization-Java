package day16;

public class Mutilevel {
	public static void main(String[] args) {
		EvCar e = new EvCar();
		e.Battery();
		e.Drive();
		e.StartEngine();
	}
}

package day16;

public class Bike extends Vehicle{
	public void Start() {
		System.out.println("Kick To Start!");
	}
}

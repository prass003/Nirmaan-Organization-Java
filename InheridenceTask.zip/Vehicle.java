package day16;

public class Vehicle {
	public void StartEngine() {
		System.out.println("Engine Started !!!");
	}
}

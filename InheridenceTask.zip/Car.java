package day16;

public class Car extends Vehicle {
	public void Drive() {
		System.out.println("Car Is Driving !!");
	}
}

package day16;

public class Single {

	public static void main(String[] args) {
		Car c= new Car();
		c.StartEngine();
		c.Drive();

	}

}

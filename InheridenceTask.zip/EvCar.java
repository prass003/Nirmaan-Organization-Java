package day16;

public class EvCar extends Car {
	public void Battery() {
		System.out.println("Electric Car Is Charging ");
	}
}

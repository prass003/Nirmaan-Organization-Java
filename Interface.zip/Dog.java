package day18;

public class Dog implements Animal{

	@Override
	public void move() {
		System.out.println("The Dog runs on four legs");
		
	}
	@Override
	 public void speak() {
		System.out.println("dog");
	}
	
}

package day18;

public class Bird implements Animal {

	@Override
	public void move() {
		System.out.println("The Bird Flies On the Sky");
		
	}
	public void speak() {
		System.out.println("The Bird says : Chirp Chirp");
	}
	
}

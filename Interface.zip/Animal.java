package day18;

 interface Animal {
	 String CATEGORY = "Living Being";
	 static String IsMammal(String animalName) {
		 if (animalName.equalsIgnoreCase("dog") || (animalName.equalsIgnoreCase("cat")) ||(animalName.equalsIgnoreCase("human"))) {
			return "true";
		}
		 else {
			 return "false";
		 }
	 }
	 public default void speak() {
		 System.out.println("Animal is Making Sound");
	 }
	 abstract void move();

}

package LibraryManagement;

public class Books {
	private int Bookid;
	private String Bookname;
	private String Bookauthor;
	private double Bookprice;
	
	
	public Books(int bookid, String bookname, String bookauthor, double bookprice) {
		super();
		Bookid = bookid;
		Bookname = bookname;
		Bookauthor = bookauthor;
		Bookprice = bookprice;
	}
	
	public Books() {
		super();
	}

	public int getBookid() {
		return Bookid;
	}
	public void setBookid(int bookid) {
		Bookid = bookid;
	}
	public String getBookname() {
		return Bookname;
	}
	public void setBookname(String bookname) {
		Bookname = bookname;
	}
	public String getBookauthor() {
		return Bookauthor;
	}
	public void setBookauthor(String bookauthor) {
		Bookauthor = bookauthor;
	}
	public double getBookprice() {
		return Bookprice;
	}
	public void setBookprice(double bookprice) {
		Bookprice = bookprice;
	}
	@Override
	public String toString() {
		return "Book [Bookid=" + Bookid + ", Bookname=" + Bookname + ", Bookauthor=" + Bookauthor + ", Bookprice="
				+ Bookprice + "]";
	}
	
	
	
	
}

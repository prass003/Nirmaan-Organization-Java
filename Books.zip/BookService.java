package LibraryManagement;

import java.util.ArrayList;
import java.util.Scanner;

public class BookService {
	Scanner sc = new Scanner(System.in);

	// add Books
	public Books addBook() {

		System.out.println("Enter the Book ID ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Book Name ");
		String name = sc.nextLine();
		System.out.println("Enter the Book author ");
		String author = sc.nextLine();
		System.out.println("Enter the Book price");
		double price = sc.nextDouble();

		return new Books(id, name, author, price);

	}

	// read Books
	public void getBooks(ArrayList<Books> Boo) {
		System.out.println(Boo);

	}

	
	public Books getBookById(int id, ArrayList<Books> Boo) {

		for (Books emp : Boo) {
			if (emp.getBookid()== id) {
				return emp;
			}
		}

		return null;

	}
	
	

}

package semsproject;

import java.util.Scanner;

import java.util.Scanner;

public class UI {
    public static void main(String[] args) {
        Library le1 = new Library();
        Scanner sc = new Scanner(System.in);
        boolean isWork = true;

        while (isWork) {
        	System.out.println("------------------------------");
            System.out.println("Enter 1 to Add Book");
            System.out.println("Enter 2 to Update Book");
            System.out.println("Enter 5 to Specific change");
            System.out.println("Enter 3 to Show Book");
            System.out.println("Enter 4 to Exit");
            System.out.println("Choose an option: ");
            System.out.println("------------------------------");
            int choose = sc.nextInt();
            sc.nextLine(); 

            switch (choose) {
                case 1:
                    System.out.print("Enter the BookId: ");
                    int id = sc.nextInt();
                    sc.nextLine(); 
                    System.out.print("Enter the BookName: ");
                    String name = sc.nextLine();
                    System.out.print("Enter the BookPrice: ");
                    int price = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter the BookAuthor: ");
                    String author = sc.nextLine();
                    le1 = new Library(id, name, price, author);
                    break;

                case 2:
                    System.out.print("Enter the BookId: ");
                    int id1 = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter the BookName: ");
                    String name1 = sc.nextLine();
                    System.out.print("Enter the BookPrice: ");
                    int price1 = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter the BookAuthor: ");
                    String author1 = sc.nextLine();
                    le1.setId(id1);
                    le1.setBookName(name1);
                    le1.setPrice(price1);
                    le1.setAuthor(author1);
                    break;

                case 3:
                    System.out.println(le1);
                    break;

                case 4:
                    isWork = false;
                    System.out.println("Thank you for visiting!");
                    break;
                case 5:
                	
                 	boolean work = true;
                	while(work) {
                		System.out.println("------------------------------");
                		System.out.println("Enter 1 to change ID");
                		System.out.println("Enter 2 to change name");
                		System.out.println("Enter 3 to exit");
                		System.out.println("Enter the Choice : ");
                		System.out.println("------------------------------");
                    	int choice2 = sc.nextInt();
                    	sc.nextLine(); 
                		
                		switch(choice2) {
                    	case 1:
                    		System.out.println("Enter the Valid id :");
                    		int newID = sc.nextInt();
                    		le1.setId(newID);
                    		break;
                    	case 2:
                    		System.out.println("Enter the Nam : ");
                    		String NewName = sc.nextLine();
                    		le1.setBookName(NewName);
                    	case 3:
                    		work = false;
                    		System.out.println("Thank You");
                    	}
                	}
                	

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        sc.close();
    }
}
